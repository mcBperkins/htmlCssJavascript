// Bradley Perkins
console.log("External file loaded")
document.write("I learned a lot of new Javascript today")